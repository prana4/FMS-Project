var button;

let circle_x_1 = 100;
let circle_y_1 = 250;

let rect_x_2 = 25;
let rect_y_2 = 340;

let square_x_3 = 50;
let square_y_3 = 475;

let isDraggingSquare;
let isDraggingRect;
let isDraggingCircle = false;

let squareInPlace = false;
let rectInPlace = false;
let circleInPlace = false;


//a class to drag objects
class Draggable {
  constructor(x, y, w, h) {
    this.dragging = false; // Is the object being dragged?
    this.rollover = false; // Is the mouse over the ellipse?
    this.x = x;
    this.y = y;
    this.w = w;
    this.h = h;
    this.offsetX = 0;
    this.offsetY = 0;
  }

  over() {
    // mouse over object
    if (mouseX > this.x && mouseX < this.x + this.w && mouseY > this.y && mouseY < this.y + this.h) {
      this.rollover = true;
    } else {
      this.rollover = false;
    }
  }

  update() {
    // Adjust location if being dragged
    if (this.dragging) {
      this.x = mouseX + this.offsetX;
      this.y = mouseY + this.offsetY;
    }
  }

  show() {
    stroke(0);
    if (this.dragging) {
      fill(194,234,194);
    } else if (this.rollover) {
      fill(194,234,194);
    } else {
      fill(194,234,194);
    }
    rect(this.x, this.y, this.w, this.h);
  }

  pressed() {

    if (mouseX > this.x && mouseX < this.x + this.w && mouseY > this.y && mouseY < this.y + this.h) {
      this.dragging = true;

      this.offsetX = this.x - mouseX;
      this.offsetY = this.y - mouseY;
    }
  }

  released() {
    // Quit dragging
    this.dragging = false;
  }
}

function preload() {
  backgroundImage = loadImage('Matching Bg.png');
}

function setup() {
  
  createCanvas(600, 600);
  isDraggingSquare = new Draggable(square_x_3, square_y_3, 100,100);
  isDraggingRect = new Draggable(rect_x_2,rect_y_2,160,100);
  
}

function draw() {
  image(backgroundImage,0,0);


  textFont('Comfortaa');
  fill('#024605');
  textSize(35);
  text('Let\'s match some shapes!', 150, 100);

  main_game();
}

function main_game() {
  
  // stationary objects
  fill(255);
  square(420, 200, 100);
  fill(255);
  rect(400,345,160,100);
  fill(255);
  circle(475, 540, 110);

  // movable objects
  fill(194,234,194);

  circle(circle_x_1, circle_y_1, 110);
  
  isDraggingSquare.over();
  isDraggingSquare.update();
  isDraggingSquare.show();
  
  isDraggingRect.over();
  isDraggingRect.update();
  isDraggingRect.show(); 
  
  if(isDraggingCircle){
    circle_x_1 = mouseX;
    circle_y_1 = mouseY;
  }  
  
 if (
    dist(circle_x_1, circle_y_1, 525, 600) < 125 / 2 &&
    !circleInPlace
  ) {
    circleInPlace = true;
  }
  if (
    circle_x_1 > 450 - 60 && circle_x_1 < 450 + 60 &&
    circle_y_1 > 200 - 60 && circle_y_1 < 200 + 60 &&
    !squareInPlace
  ) {
    squareInPlace = true;
  }
  if (
    rect_x_2 > 420 - 100 && rect_x_2 < 420 + 100 &&
    rect_y_2 > 375 - 57.5 && rect_y_2 < 375 + 57.5 &&
    !rectInPlace
  ) {
    rectInPlace = true;
  }

  if (squareInPlace && rectInPlace && circleInPlace) {
    // All shapes are in place
      image(backgroundImage,0,0);


    fill(2,99,2);
    textSize(30);
    text('Good Job! You matched all shapes!', 80, 320);
    
  button = createButton("Back");
  button.size(100, 50);
  button.position(275, 400);
  button.mousePressed(back);
  let col = color(231,237,250); 
    
  
  button.style('font-size', '20px');
  button.style('background-color', col);
  button.style("font-family", "Veranda");
    
    
  }
}


//drag and drop objects

function mousePressed() {
  isDraggingSquare.pressed();
  isDraggingRect.pressed();
  
   if(dist(circle_x_1, circle_y_1, mouseX, mouseY) < 125/2){
    isDraggingCircle = true;
  }
}

function mouseReleased() {
  isDraggingSquare.released();
  isDraggingRect.released();
  
  isDraggingCircle = false;
  
  if (dist(circle_x_1, circle_y_1, 475, 540) < 125 / 2 && !circleInPlace) {
    circle_x_1 = 475;
    circle_y_1 = 540;
    circleInPlace = true;
  }
  
  if (
    dist(isDraggingSquare.x, isDraggingSquare.y, 420, 200) < 60 &&
    !squareInPlace
  ) {
    isDraggingSquare.x = 420;
    isDraggingSquare.y = 200;
    squareInPlace = true;
  }

  if (
    
    dist(isDraggingRect.x, isDraggingRect.y, 400, 345) < 57.5 &&
    !rectInPlace
  ) {
    isDraggingRect.x = 400;
    isDraggingRect.y = 345;
    rectInPlace = true;
  } 
}

function back() {
 window.open("https://editor.p5js.org/prana4/full/bmiY29Snq");
}
