let currentColor = 'black';
let palette = ['#000000', '#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', '#00FFFF', '#FFFFFF'];
let paletteButtons = [];
let slider;
let eraserButton;
let backButton;

function setup() {
  createCanvas(600, 600);
  background(300);
  
  // Create palette buttons
    let buttonWidth = width / palette.length;
    for (let i = 0; i < palette.length; i++) {
    let button = createButton('');
    button.position(i * buttonWidth, height + 10);
    button.size(buttonWidth, 30);
    button.style('background-color', palette[i]);
    button.mousePressed(changeColor);
    paletteButtons.push(button);
    
    let col = color(209,233,243); 
    backButton = createButton('Back');
    backButton.size(100,50);
    backButton.position(475, 25);
    backButton.style('font-size', '21px');
    backButton.style('background-color', col);
    backButton.style("font-family", "Veranda");
    backButton.mousePressed(back);    
  }
  
  let resetButton = createButton('Reset');
  let col = color(209,233,243); 
  resetButton.size(100,50);
  resetButton.position(10,25);
  resetButton.style('font-size', '21px');
  resetButton.style('background-color', col);
  resetButton.style("font-family", "Veranda");
  resetButton.mousePressed(reset);
  
  // Create slider for brush width
  slider = createSlider(1, 20, 5, 1);
  slider.position(width + 20, height / 2 - 20);

  // Create eraser button
  eraserButton = createButton('Eraser');
  eraserButton.position(width + 20, height / 2 + 20);
  eraserButton.size(100, 50);
  eraserButton.style('font-size', '21px');
  eraserButton.style('background-color', col);
  eraserButton.style("font-family", "Veranda");
  eraserButton.mousePressed(() => {
    currentColor = '#FFFFFF'; // Set color to white for eraser
  });
}

function draw() {
  // Draw palette buttons
  for (let button of paletteButtons) {
    button.show();
  }

  // Draw brush width text
  fill(0);
  text(`Brush Width: ${slider.value()}`, width + 20, height / 2 - 30);

  // Draw slider
  slider.show();

  // Draw eraser button
  eraserButton.show();

  // Paint on canvas
  if (mouseIsPressed) {
    strokeWeight(slider.value());
    stroke(currentColor);
    line(pmouseX, pmouseY, mouseX, mouseY);
  }
}

// Choose Color 
function changeColor() {
  let index = paletteButtons.indexOf(this);
  currentColor = palette[index];
}

// Reset Function
function reset(){
  createCanvas(600,600);
}

function back(){
   window.open('https://editor.p5js.org/prana4/full/bmiY29Snq');
}
