let dir;
let picture;

const diff = 10;
var backButton;
let xFruit = 0;
let yFruit = 0;
let scoreElem;
let basket;
let fruit;
let score = 0;

function preload(){
  picture = loadImage('Tracing Start Screen.png');
  
}

function setup() {
  //score
  image(picture,0,0);
  scoreElem = createDiv("Score = " + score);
  scoreElem.position(20, 20);
  scoreElem.id = "score";
  scoreElem.style("color", "rgb(0,0,0)");

  

  //new basket object
  basket = new Basket();
  fruit = new Fruit();
  createCanvas(625, 625);
  
  backButton = createButton('Back');
  backButton.position(575, 20);
  backButton.mousePressed(back);
}

function draw() {
  image(picture,0,0);
  basket.display();
  fruit.display();
  fruit.updateY();
  checkBasket();
  ifGameOver();
}

function randomX() {
  var ranX = random(25, 600);
  return ranX;
}

function ifGameOver() {
  if (fruit.y >= height) {
    noLoop();
    const scoreVal = parseInt(scoreElem.html().substring(8));
    scoreElem.html("Game ended! Your score was : " + scoreVal);
    scoreElem.position(200, 225);
    backButton.position(300, 250);
  }
}
function checkBasket() {
  if (fruit.y >= 575 && fruit.x >= mouseX - 50 && fruit.x <= mouseX + 50) {
    const prevScore = parseInt(scoreElem.html().substring(8));
    scoreElem.html("Score = " + (prevScore + 1));
    score++;
    fruit.reset();
  } else {
    return false;
  }
}

class Basket {
  constructor() {
    this.y = 575;
  }

  display() {
    rect(mouseX - 50, this.y, 100, 25);
    fill("red");
  }
}


class Fruit {
  constructor() {
    this.x = randomX();
    this.y = 0;
    this.dia = 30;
    this.ySpeed = 2;
  }

  updateY() {
    this.ySpeed = score / 3 + 2;
    this.y += this.ySpeed;
  }
  reset() {
    this.x = randomX();
    this.y = 0;
  }

  display() {
    ellipse(this.x, this.y, this.dia);
    fill("orange");
  }
}
function back() {
  window.open('https://editor.p5js.org/prana4/full/bmiY29Snq');
}