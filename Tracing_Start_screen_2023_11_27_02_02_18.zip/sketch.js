var button;
var button2;
var button3;
var backButton;

let draft;


function preload() {
  draft = loadImage("Tracing Start Screen.png");
}

function setup() {
  createCanvas(600, 600);
  image(draft, 0, 0);
  button = createButton("Trace Letter A");
  let col = color(240,251,252); 
  button.style('font-size', '16px');
  button.style('background-color', col);
  button.style("font-family", "Veranda");
  button.size(100,75)
  button.position(150, 150);
  button.mousePressed(letterA);

  button2 = createButton("Trace Letter B");
  button2.size(100,75);
  button2.style('font-size', '16px');
  button2.style('background-color', col);
  button2.style("font-family", "Veranda");
  button2.position(325, 150);
  button2.mousePressed(letterB);
  

  button3 = createButton("Trace Letter C");
  button3.size(100,75);
  button3.position(150, 250);
  button3.style('font-size', '16px');
  button3.style('background-color', col);
  button3.style("font-family", "Veranda");
  button3.mousePressed(letterC);

  var backButton = createButton("Back");
  backButton.size(100,75);
  backButton.position(325, 250);
  backButton.style('font-size', '16px');
  backButton.style('background-color', col);
  backButton.style("font-family", "Veranda");
  backButton.mousePressed(back);
}

function letterA() {
  window.open("https://editor.p5js.org/prana4/full/qibI7UR_e");
}

function letterB() {
  window.open("https://editor.p5js.org/prana4/full/XjarTK-8S");
}
function letterC() {
  window.open("https://editor.p5js.org/prana4/full/Vw5M0kz3o");
}
function back() {
  window.open("https://editor.p5js.org/prana4/full/bmiY29Snq");
}
