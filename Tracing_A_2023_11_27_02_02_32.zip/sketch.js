var button;

let draft, ready;
function preload() {
  ready = loadImage('A background.png');
  draft = loadImage('Background.png');
}
function setup() {
  createCanvas(550, 720);
  noCursor();
  cursor('assets/brush.png', 20, -10);
  image(ready, 0, 0);
  image(draft, 0, 0);
  
  button = createButton('Back');
  button.size(90, 25);
  button.position(200 , 15);
  button.mousePressed(back);
  
  
}
function mouseDragged() {
  copy(ready, mouseX, mouseY, 10, 10, mouseX, mouseY, 10, 10);
}

function back() {
  window.open('https://editor.p5js.org/prana4/full/_PBximtAZ');
}
