let picture;

function preload() {
  picture = loadImage('Screen Shot 2023-11-18 at 11.37.19 PM.png');
}

function setup(){
  createCanvas(650, 600);
  image(picture, 0 , 0);
  var button = createButton('START');
  button.position(275, 225);
  button.size(100, 50);
  button.mousePressed(screen1);
  let col = color(232,236,246); 
  button.style('font-size', '19px');
  button.style('background-color', col);
  button.style("font-family", "Veranda");
  var backButton = createButton('Back');
  backButton.size(100, 50);
  backButton.position(275, 300);
  backButton.mousePressed(back);
  backButton.style('font-size', '19px');
  backButton.style('background-color', col);
  backButton.style("font-family", "Veranda");
  
}

function screen1(){
  window.open('https://editor.p5js.org/prana4/full/1_DiZVW8N');
  
}
function back() {
  window.open('https://editor.p5js.org/prana4/full/bmiY29Snq');
}
