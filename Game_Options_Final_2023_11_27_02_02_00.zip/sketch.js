let draft;

let bg;
let button;


function preload() {
  draft = loadImage("Game Options Background.png");
}

function setup() {
  createCanvas(625, 625);
  image(draft, 0, 0);
  
   
  textFont('Comfortaa');
  fill('#264403');
  textSize(60);
  text('FunFlow', 200, 130);

 var button = createButton('Tracing');
  button.size(150,100)
  let col = color(209,233,243); 
  button.position(150 ,200);
  button.style('font-size', '21px');
  button.style('background-color', col);
  button.style("font-family", "Veranda");
  button.mousePressed(activity1);

  var button = createButton('Drawing');
  button.size(150,100)
  button.position(350 ,200);
  button.style('font-size', '21px');
  button.style('background-color', col);
  button.style("font-family", "Veranda");
  button.mousePressed(activity2);
  
  
  var button = createButton('Catching');
  button.size(150,100);
  button.position(150 ,325);
  button.mousePressed(activity3);
  button.style('font-size', '21px');
  button.style('background-color', col);
  button.style("font-family", "Veranda");

 var button = createButton('Matching');
  button.size(150,100)
  button.position(350 ,325);
  button.mousePressed(activity4);
  button.style('font-size', '21px');
  button.style('background-color', col);
  button.style("font-family", "Veranda");

}

function activity1 () {
  window.open('https://editor.p5js.org/prana4/full/_PBximtAZ');
}

function activity2 () {
  window.open('https://editor.p5js.org/prana4/full/kWrkMX-x7 ');
}

function activity3 () {
  window.open('https://editor.p5js.org/prana4/full/C1sbcIabj');
}

function activity4 () {
  window.open('https://editor.p5js.org/prana4/full/ZN8zQnq9l');
}


